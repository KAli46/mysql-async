description "vRP MySQL"

-- server scripts
server_scripts{ 
  "@vrp/lib/utils.lua",
  "MySQL.lua",
}