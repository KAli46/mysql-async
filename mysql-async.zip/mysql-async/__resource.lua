resource_manifest_version '44febabe-d386-4d18-afbe-5e627f4af937'

server_script 'MySQLAsync.net.dll'
server_script 'lib/init.lua'
--server_script 'lib/MySQL.lua'
--server_script 'example.lua'
